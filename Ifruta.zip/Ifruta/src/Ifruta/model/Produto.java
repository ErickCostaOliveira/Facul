/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ifruta.model;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

/**
 *
 * @author F E L I P E
 */
public class Produto {

       private String NomeProduto;

    public static final String PROP_NOMEPRODUTO = "NomeProduto";

    public String getNomeProduto() {
        return NomeProduto;
    }

    public void setNomeProduto(String NomeProduto) {
        String oldNomeProduto = this.NomeProduto;
        this.NomeProduto = NomeProduto;
        propertyChangeSupport.firePropertyChange(PROP_NOMEPRODUTO, oldNomeProduto, NomeProduto);
    }

    private transient final PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(listener);
    }

    private float PrecoProduto;

    public static final String PROP_PRECOPRODUTO = "PrecoProduto";

    public float getPrecoProduto() {
        return PrecoProduto;
    }

    public void setPrecoProduto(float PrecoProduto) {
        float oldPrecoProduto = this.PrecoProduto;
        this.PrecoProduto = PrecoProduto;
        propertyChangeSupport.firePropertyChange(PROP_PRECOPRODUTO, oldPrecoProduto, PrecoProduto);
    }

    private int QuantidadeProduto;

    public static final String PROP_QUANTIDADEPRODUTO = "QuantidadeProduto";

    public int getQuantidadeProduto() {
        return QuantidadeProduto;
    }

    public void setQuantidadeProduto(int QuantidadeProduto) {
        int oldQuantidadeProduto = this.QuantidadeProduto;
        this.QuantidadeProduto = QuantidadeProduto;
        propertyChangeSupport.firePropertyChange(PROP_QUANTIDADEPRODUTO, oldQuantidadeProduto, QuantidadeProduto);
    }


    private String OrigemProduto;

    public static final String PROP_ORIGEMPRODUTO = "OrigemProduto";

    public String getOrigemProduto() {
        return OrigemProduto;
    }

    public void setOrigemProduto(String OrigemProduto) {
        String oldOrigemProduto = this.OrigemProduto;
        this.OrigemProduto = OrigemProduto;
        propertyChangeSupport.firePropertyChange(PROP_ORIGEMPRODUTO, oldOrigemProduto, OrigemProduto);
    }

        private String DescricaoProduto;

    public static final String PROP_DESCRICAOPRODUTO = "DescricaoProduto";

    public String getDescricaoProduto() {
        return DescricaoProduto;
    }

    public void setDescricaoProduto(String DescricaoProduto) {
        String oldDescricaoProduto = this.DescricaoProduto;
        this.DescricaoProduto = DescricaoProduto;
        propertyChangeSupport.firePropertyChange(PROP_DESCRICAOPRODUTO, oldDescricaoProduto, DescricaoProduto);
    }

 
}
