package Ifruta.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author erick
 */
public abstract class DAO<E> {

    public abstract boolean inserir(E e);
    public abstract boolean alterar(E e);
    public abstract List<E> listar();
    
    protected Connection conn;
    
    public DAO(){
        String url = "jdbc:mysql://localhost/ifruta";
        String user = "root";
        String password = "";
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(url,user, password);
        }catch(SQLException e){
            System.out.println("Erro ao conectar");
        }catch(ClassNotFoundException e){
            System.out.println("Erro no driver");
        }
    }
}