package Ifruta.db;

import Ifruta.model.Cliente;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author erick
 */
public class ClienteDAO extends DAO<Cliente> {

    @Override
    public boolean inserir(Cliente e) {
        String sql = "INSERT INTO cliente (nome,cidade,senha,endereco,numero,bairro,complemento,estado,cpf,email,telefone) VALUES (?,?,?,?,?,?,?,?,?,?)";
        try(
            PreparedStatement stmt = conn.prepareStatement(sql,
                                            Statement.RETURN_GENERATED_KEYS);
        ){
            stmt.setString(1, e.getNome());
            stmt.setString(2, e.getSenha());
            stmt.setString(3, e.getEndereco());
            stmt.setInt(4, e.getNumero());
            stmt.setString(5, e.getBairro());
            stmt.setString(6, e.getComplemento());
            stmt.setString(7, e.getEstado());
            stmt.setString(8, e.getCpf());
            stmt.setString(9, e.getEmail());
            stmt.setString(10, e.getTelefone());
            
            
            if(stmt.executeUpdate()==1){
                ResultSet rs = stmt.getGeneratedKeys();
                rs.next();
                e.setId_Cliente(rs.getInt(1));
                return true;
            }
            
        }catch(SQLException ex){
            System.out.println("erro ao inserir");
        }
        
        
        return false;
    }

    @Override
    public List<Cliente> listar() {
        List<Cliente> lst = new LinkedList<>();
        lst = org.jdesktop.observablecollections
                        .ObservableCollections.observableList(lst);
        
        String sql = "SELECT * FROM cliente";
        try(
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
        ){
            while(rs.next()){
                Cliente c = new Cliente();
                c.setId_Cliente(rs.getInt("id_cliente"));
                c.setNome(rs.getString("nome"));
                //c.setCidade(rs.getString("cidade"));
                c.setSenha(rs.getString("senha"));
                c.setEndereco(rs.getString("endereco"));
                c.setNumero(rs.getInt("numero"));
                c.setBairro(rs.getString("bairro"));
                c.setComplemento(rs.getString("complemento"));
                c.setEstado(rs.getString("estado"));
                c.setCpf(rs.getString("cpf"));
                c.setEmail(rs.getString("email"));
                c.setTelefone(rs.getString("telefone"));
                lst.add(c);
            }
        }catch(SQLException e){
            System.out.println("erro ao listar");
        }
        
        return lst;
    }

    @Override
    public boolean alterar(Cliente e) {
        String sql = "UPDATE cliente SET nome=?,cidade=?,senha=?,endereco=?,numero=?,bairro=?,complemento=?,estado=?,cpf=?,email=?,telefone=? WHERE id_cliente=?";
        try(
            PreparedStatement stmt = conn.prepareStatement(sql);
        ){
            stmt.setString(1, e.getNome());
            stmt.setString(2, e.getSenha());
            stmt.setString(3, e.getEndereco());
            stmt.setInt(4, e.getNumero());
            stmt.setString(5, e.getBairro());
            stmt.setString(6, e.getComplemento());
            stmt.setString(7, e.getEstado());
            stmt.setString(8, e.getCpf());
            stmt.setString(9, e.getEmail());
            stmt.setString(10, e.getTelefone());
            return stmt.executeUpdate()==1;
        }catch(SQLException ex){
            System.out.println("erro ao alterar");
        }
        return false;
    }

    
    public Cliente getById(int id){
        Cliente c = null;
        
        String sql = "SELECT * FROM cliente WHERE id_cliente="+id;
        
        try(
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
        )
        {
            if(rs.next())
            {
                c = new Cliente();
                c.setId_Cliente(rs.getInt("id_cliente"));
                c.setNome(rs.getString("nome"));
                //c.setCidade(rs.getString("cidade"));
                c.setSenha(rs.getString("senha"));
                c.setEndereco(rs.getString("endereco"));
                c.setNumero(rs.getInt("numero"));
                c.setBairro(rs.getString("bairro"));
                c.setComplemento(rs.getString("complemento"));
                c.setEstado(rs.getString("estado"));
                c.setCpf(rs.getString("cpf"));
                c.setEmail(rs.getString("email"));
                c.setTelefone(rs.getString("telefone"));
            }
        }catch(SQLException e){
            System.out.println("erro ao buscar Cliente pelo Id");
        }
        return c;
    }
    
    
}


