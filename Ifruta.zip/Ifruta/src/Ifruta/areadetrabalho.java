/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ifruta;

import java.beans.PropertyVetoException;
import javax.swing.JDesktopPane;

/**
 *
 * @author F E L I P E
 */
public class areadetrabalho extends JDesktopPane {
    
    private cadastroproduto CadProduto;
    private CadastroCliente CadCliente;
    private CadastroFeirante CadFeirante;
    private CadastroEntregador CadEntregador;
    
    void abrircadastroproduto(){
        if(CadProduto==null)
        {
          CadProduto = new cadastroproduto();
          add(CadProduto);
          CadProduto.setVisible(true);
        }else
        {
            try
            {
                CadProduto.setSelected(true);
                CadProduto.setIcon(false);
                CadProduto.moveToFront();
            }catch(PropertyVetoException e)
            {
                System.out.printf("faiô a janela ai tio!");
            }
        }
    }
    
    void abrircadastrofeirante(){
        if(CadFeirante==null)
        {
          CadFeirante = new CadastroFeirante();
          add(CadFeirante);
          CadFeirante.setVisible(true);
        }else
        {
            try
            {
                CadFeirante.setSelected(true);
                CadFeirante.setIcon(false);
                CadFeirante.moveToFront();
            }catch(PropertyVetoException e)
            {
                System.out.printf("faiô a janela ai tio!");
            }
        }
    }
    
    void abrircadastrocliente(){
        if(CadCliente==null)
        {
          CadCliente = new CadastroCliente();
          add(CadCliente);
          CadCliente.setVisible(true);
        }else
        {
            try
            {
                CadCliente.setSelected(true);
                CadCliente.setIcon(false);
                CadCliente.moveToFront();
            }catch(PropertyVetoException e)
            {
                System.out.printf("faiô a janela ai tio!");
            }
        }
    }
    
     void abrircadastroentregador(){
        if(CadEntregador==null)
        {
          CadEntregador = new CadastroEntregador();
          add(CadEntregador);
          CadEntregador.setVisible(true);
        }else
        {
            try
            {
                CadEntregador.setSelected(true);
                CadEntregador.setIcon(false);
                CadEntregador.moveToFront();
                CadEntregador.setVisible(true);
            }catch(PropertyVetoException e)
            {
                System.out.printf("faiô a janela ai tio!");
            }
        }
    }
    
    void fechacadastroproduto(){
        CadProduto=null;
    }
    
    void fechacadastrofeirante(){
        CadFeirante=null;
    }
    
    void fechacadastrocliente(){
        CadCliente=null;
    }
    
    void fechacadastroentregador(){
        CadEntregador=null;
    }
}
