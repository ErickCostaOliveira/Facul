package Ifruta;

import Ifruta.model.Produto;
import Ifruta.model.Feirante;
import Ifruta.model.Entregador;
import Ifruta.model.Cliente;
import java.util.List;
import java.util.LinkedList;

public class dados
{
	private static dados instancia;
	private List<Produto> lstprodutos;
        private List<Cliente> lstclientes;
        private List<Feirante> lstfeirantes;
        private List<Entregador> lstentregadores;
	
	public static dados getInstance(){
		if(instancia == null)
			instancia = new dados();
		return instancia;
	}
	
	private dados()
	{
		lstprodutos= new LinkedList<>();
                lstfeirantes= new LinkedList<>();
                lstentregadores= new LinkedList<>();
                lstclientes= new LinkedList<>();
                lstprodutos= org.jdesktop.observablecollections.ObservableCollections.observableList(lstprodutos);
                lstfeirantes= org.jdesktop.observablecollections.ObservableCollections.observableList(lstfeirantes);
                lstentregadores= org.jdesktop.observablecollections.ObservableCollections.observableList(lstentregadores);
                lstclientes= org.jdesktop.observablecollections.ObservableCollections.observableList(lstclientes);
                
	}
	
	public List<Produto> getLstProdutos(){
		return lstprodutos;
	}
        
	public List<Feirante> getLstFeirantes(){
		return lstfeirantes;
	}

        public List<Entregador> getLstEntregadores(){
		return lstentregadores;
	}
        
        public List<Cliente> getLstClientes(){
		return lstclientes;
	}
        
}