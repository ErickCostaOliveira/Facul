CREATE TABLE cliente (
 id_cliente INT AUTO_INCREMENT NOT NULL,
 nome VARCHAR(40) NOT NULL,
 cidade VARCHAR(30),
 senha VARCHAR(30),
 endereco VARCHAR(30),
 numero INT,
 bairro VARCHAR(30),
 complemento VARCHAR(30),
 estado VARCHAR(30),
 cpf VARCHAR(15),
 email VARCHAR(30),
 telefone VARCHAR(15),
 CONSTRAINT pk_cliente PRIMARY KEY (id_cliente));
 
 CREATE TABLE feirante (
 Id_feirante INT AUTO_INCREMENT NOT NULL ,
 nome VARCHAR(40) NOT NULL ,
 senha VARCHAR(30),
 endereco VARCHAR(30),
 numero INT NULL,
 bairro VARCHAR(30),
 complemento VARCHAR(30),
 estado VARCHAR(30),
 email VARCHAR(30),
 telefone VARCHAR(15),
 documento VARCHAR(15),
 CONSTRAINT pk_feirante PRIMARY KEY (Id_feirante));

CREATE TABLE entregador (
 Id_entregador INT AUTO_INCREMENT NOT NULL ,
 nome VARCHAR(40) NOT NULL ,
 endereco VARCHAR(30),
 numero INT NULL,
 email VARCHAR(30),
 telefone VARCHAR(15),
 cpf VARCHAR(15),
 CONSTRAINT pk_entregador PRIMARY KEY (Id_entregador));

CREATE TABLE produto (
 Id_produto INT AUTO_INCREMENT NOT NULL ,
 descricaProduto VARCHAR(30) NOT NULL ,
 OrigemProduto VARCHAR(30) NOT NULL,
 PrecoProduto FLOAT NOT NULL ,
 QuantidadeProduto INT NULL ,
 CONSTRAINT pk_produto PRIMARY KEY (Id_produto));

